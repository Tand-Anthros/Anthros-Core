## Добро пожаловать в Anthros-Core!
> Вместе - всё просто</br>

Набор инструментов для разработчиков и универсальное приложение для пользователей</br>

## Как начать?
Скачайте [архив](https://github.com/Thunder-Light/Anthros-Core/archive/refs/heads/main.zip), распакуйте и запустите run.bat для windows или run.sh для linux</br>
А так же вы можете установить anthros-core как [библиотеку](https://pypi.org/project/anthros-core/) python</br>
</br>
AC крайне разнесторонний. Пожалуйста выберите подходящее для вас руководство. Так вы найдете действительно то что вам нужно</br>
Краткие руководства для [пользователей](src/anthros/docs/rus/users.md), [разработчиков](src/anthros/docs/rus/developers.md), [моддеров](src/anthros/docs/rus/modders.md)

## Кроме того
Заходите в наши сообщества: [Discord](https://discord.gg/3zR4Ffa6mX), [Vk](https://vk.com/anthros)</br>
Напишите [мне](https://vk.com/thunder_light) или добавтесь в Discord (Tand#9533) если будут вопросы