#import anthros
#from anthros import core as ac

#doc = anthros.__doc__
#print(doc)

print(_test.interact.__doc__)