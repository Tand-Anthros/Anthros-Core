import anthros

anthros.interfaces.console.run()