import os
os.remove(__file__)